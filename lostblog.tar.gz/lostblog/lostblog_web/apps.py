from django.apps import AppConfig


class LostblogWebConfig(AppConfig):
    name = 'lostblog_web'
